package com.example.st10384670poepart_oneimad

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val numberone = findViewById<EditText>(R.id.editTextNumber)
        val numbertwo = findViewById<EditText>(R.id.editTextNumber2)
        val addition = findViewById<Button>(R.id.btnAddition)
        val subtraction = findViewById<Button>(R.id.btnSubtraction)
        val division = findViewById<Button>(R.id.btnDivision)
        val Multiplication = findViewById<Button>(R.id.btnMultiplication)
        val answer = findViewById<TextView>(R.id.tvAnswer)
        var output = findViewById<TextView>(R.id.tvOutput)

        addition.setOnClickListener {
            val numberone = numberone.text.toString().toInt()
            val numbertwo = numbertwo.text.toString().toInt()
            val addition = numberone + numbertwo
            output.text = "$numberone + $numbertwo = $addition"
        }

        subtraction.setOnClickListener {
            val numberone = numberone.text.toString().toInt()
            val numbertwo = numbertwo.text.toString().toInt()
            val subtraction = numberone - numbertwo
            output.text = "$numberone _ $numbertwo = $addition"
        }

        Multiplication.setOnClickListener {
            val numberone = numberone.text.toString().toInt()
            val numbertwo = numbertwo.text.toString().toInt()
            val multiplication = numberone*numbertwo
            output.text = "$numberone * $numbertwo = $multiplication"
        }


        division.setOnClickListener {
            if (numberone.text.toString() == "") {
                Toast.makeText(this, "please enter your first number!", Toast.LENGTH_LONG).show()
            } else if (numbertwo.text.toString() == "") {
                Toast.makeText(this, "please enter your second number!", Toast.LENGTH_LONG).show()
            } else {
                if (numbertwo.text.toString().toInt() == 0) {
                    output.text = "Error\nSecond Number Cannot be 0"
                } else {
                }
            }
        }


    }
}